<?php include("header.php")
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body background="background/admin.jpg"> 
	<div class="modal-dialog text-center">
		<div class="col-sm-9 main-secton">
			<div class="modal-content">
				<div class="col-12 user-img">
					<img src="image/admin.png">
			</div>

			<div class="col-12 form-input">
				<form method="post">
				<div class="form-group">
					<input type="textbox" class="form-control" placeholder="Enter Email">
			</div>
			<div class="form-group">
					<input type="textbox" class="form-control" placeholder="Enter Password">
			</div>
			<div>
			<button type="submit" class="btn btn-success"> Login </button>
			</div>
				</form>
			</div>
			<div class="col-12 forgot">
				<a href="#"> Forgot Password? </a>
			</div>
		</div>
	</div>

</body>
</html>