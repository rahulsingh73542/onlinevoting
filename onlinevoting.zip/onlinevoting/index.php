<?php include("header.php"); ?>
<!DOCTYPE html>
<html>
<head>
	<title> Online Voting System </title>
</head>
<body background="background/2.jpg">
	<div class="container max-width">
		<div class= "text-center" >
		<h1> Welcome to Online Voting System </h1>
		</div>
		<div class="w-25 p-3 position-absolute">
			<a href="admin_login.php"><img src="image/Admin.jpg"> </a>
		</div>
		<div class="w-25 float-right ">
			<a href="voter_login.php"><img width="65%" src="image/user3.png"> </a>
		</div>
	</div>
</body>
</html>